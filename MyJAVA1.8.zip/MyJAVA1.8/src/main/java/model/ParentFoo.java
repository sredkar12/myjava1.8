package model;

public class ParentFoo {
    private String parentName;
    private String ssn;
    public ParentFoo(String parentName, String ssn) {
        this.parentName = parentName;
        this.ssn = ssn;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getSsn() {
        return ssn;
    }

    public void setSsn(String ssn) {
        this.ssn = ssn;
    }


}
