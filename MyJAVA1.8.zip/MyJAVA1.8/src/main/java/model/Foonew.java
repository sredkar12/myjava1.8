package model;

public class Foonew extends Commonfoo{


    private Integer bar;
    private String baz;
    private String name;
    private String address;
    private String nationality;
    private String profession;
    private Double income;
    private Boolean isCitizen;

    public Foonew(String nickname,Integer bar, String baz, String name, String address, String nationality, String profession, Double income, Boolean isCitizen) {
        super(nickname);
        this.bar = bar;
        this.baz = baz;
        this.name = name;
        this.address = address;
        this.nationality = nationality;
        this.profession = profession;
        this.income = income;
        this.isCitizen = isCitizen;
    }


    public Boolean getCitizen() {
        return isCitizen;
    }

    public void setCitizen(Boolean citizen) {
        isCitizen = citizen;
    }

    public int getBar() {
        return bar;
    }

    public void setBar(int bar) {
        this.bar = bar;
    }

    public String getBaz() {
        return baz;
    }

    public void setBaz(String baz) {
        this.baz = baz;
    }

    public String getName() {
        return name;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }




}
