package model;

public class Foo extends ParentFoo{


    public int getBar() {
        return bar;
    }

    public void setBar(int bar) {
        this.bar = bar;
    }

    public String getBaz() {
        return baz;
    }

    public void setBaz(String baz) {
        this.baz = baz;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Foo(String par, String ssn, int bar, String baz, String name, String address) {
        super(par,ssn);
        this.bar = bar;
        this.baz = baz;
        this.name = name;
        this.address = address;
    }


    private int bar;
    private String baz;
    private String name;
    private String address;


}
