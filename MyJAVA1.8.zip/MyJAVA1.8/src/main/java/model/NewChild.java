package model;

public class NewChild {
    public static void main(String[] args) {

    }
}
