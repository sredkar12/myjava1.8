package model;

public class Commonfoo {
    private String nickname;

    public Commonfoo(String nickname) {
        this.nickname = nickname;
    }
}
