package com.learnJava.data.datastructures;

import java.util.Hashtable;
import java.util.Scanner;

public class Ransomnote {

    public static void main(String[] args) {


        System.out.println("enter magazine sentence :");
        Scanner sc = new Scanner(System.in);
        String[] mg = sc.nextLine().split(" ");
        System.out.println("enter note  sentence :");
        String[] nt = sc.nextLine().split(" ");

        Hashtable<String,Integer> mgtable = new Hashtable<>();

        for(int i=0;i< mg.length; ++i) {
            if(mgtable.containsKey(mg[i])){
               int count =  mgtable.get(mg[i]);
               mgtable.put(mg[i],++count);
            }
            else
                mgtable.put(mg[i],1);
        }
        boolean WORDNOTFOUND = true;

        for(int i = 0; i < nt.length; ++i ) {
            if(mgtable.containsKey(nt[i]) )
                ;
            else {
                WORDNOTFOUND = false;
                break;
            }
        }
         if(WORDNOTFOUND)
             System.out.println("True");
         else
             System.out.println("fALSE");


    }

}
