package com.learnJava.data;


import java.util.Optional;

public class HelloWorld {
    private static String myname;
    public static void main(String[] args) {

        Event event = new Event() ;
        event.setCode1(null);
        event.setTranCode("dummy");
        System.out.println(Optional.ofNullable(event.getCode1()).isPresent());

       // Optional<String> eventCode = Optional.ofNullable(event.getCode1());
        System.out.println("eventcode is " + event.getCode1());
        String declineCode = "0076";

//        String newcode =   event.getCode1().equals("0076") || event.code1.equals("0086") ? "present" :
//            "absent";
        String newcode =  !(Optional.ofNullable(event.getCode1()).isPresent()) ? event.getTranCode() : event.getCode1();


        System.out.println("code is " + newcode);

    }

    static class Event {
        private String code1;
        private String tranCode;

        public void setCode1(String code1) {
            this.code1 = code1;
        }

        public String getCode1() {
            return code1;
        }


        public String getTranCode() {
            return tranCode;
        }

        public void setTranCode(String tranCode) {
            this.tranCode = tranCode;
        }
    }



}
