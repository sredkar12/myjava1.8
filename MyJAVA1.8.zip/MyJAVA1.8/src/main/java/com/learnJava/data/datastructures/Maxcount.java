package com.learnJava.data.datastructures;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.Iterator;

public class Maxcount {

    public static void main(String[] args) {
        String[] names = { "SAM", "VID", "ARJUN", "SAM","VID", "SAM", "JACK", "JOHN" ,
            "SAM", "ARJUN", "JOHN"};

       List<String> listnames =  Arrays.asList(names);

        Function<List<String>, Map<String, Integer>>  maxcnt = nameslst -> {
            Map<String, Integer> countmap = new HashMap<>();
            nameslst.forEach( s->  {
                if (countmap.containsKey(s)) {
                    int cnt = countmap.get(s);
                    countmap.put(s, ++cnt);
                }
                else {
                    countmap.put(s,1);
                }
            });
            return countmap;
        };

                 Map<String, Integer> mxcnt = maxcnt.apply(listnames);
                 Iterator<Map.Entry<String,Integer>> entr=  mxcnt.entrySet().iterator();

                  while(entr.hasNext())
                      System.out.println(entr.next());

    }

}
