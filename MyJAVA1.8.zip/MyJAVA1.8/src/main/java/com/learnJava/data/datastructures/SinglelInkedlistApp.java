package com.learnJava.data.datastructures;

public class SinglelInkedlistApp {


    public static void main(String[] args) {

        SinglyLinkedList singlyLinkedList ;

        Employee emp1 = new Employee("Sameer", "Redkar", 123);
        Employee emp2 = new Employee("Vidya", "Redkar", 222);
        Employee emp3 = new Employee("Arjun", "Redkar", 546);
        Employee emp4 = new Employee("Raju", "Redkar", 548);
        Employee emp5 = new Employee("Pareash", "Redkar", 549);
        singlyLinkedList = new SinglyLinkedList();
        singlyLinkedList.addToFront(emp1);
        singlyLinkedList.addToFront(emp2);
        singlyLinkedList.addToFront(emp3);
        singlyLinkedList.addToFront(emp4);
        singlyLinkedList.addToFront(emp5);

        singlyLinkedList.printLinkedlist();



    }



}
