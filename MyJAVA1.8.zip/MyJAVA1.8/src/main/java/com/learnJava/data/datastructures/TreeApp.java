package com.learnJava.data.datastructures;

public class TreeApp {

    public static void main(String[] args) {
        Treeexample tree = new Treeexample();

        tree.addNode(25);
        tree.addNode(20);
        tree.addNode(15);
        tree.addNode(27);
        tree.addNode(30);
        tree.addNode(29);
        tree.addNode(26);
        tree.addNode(22);
        tree.addNode(32);

//        tree.addNode(14);
//        tree.addNode(16);
//        tree.addNode(21);
//        tree.addNode(23);



        //tree.traverseInOrder();
        System.out.println(tree.get(27));





    }

}
