package com.learnJava.data.datastructures;

import java.util.ArrayList;
import java.util.List;

public class CommonElements {

    public static void main(String[] args) {
        int[] array1 = {1, 3, 4, 6, 7, 9, 11, 15, 19, 18};
        int[] array2 = {1, 2, 4, 5, 9, 10, 11, 19 };

        Integer[] commonarray = fincCommon(array1,array2);
        for(int k: commonarray)
        System.out.println(k);
    }

    private static Integer[] fincCommon(int[] array1, int[] array2) {
        List<Integer> commlist = new ArrayList<>();

        int commonIndex = 0;
        for(int i: array1) {
            for(int j: array2) {
                if(i == j)
                    commlist.add(i);
            }
        }
        Integer[] commonArry = new Integer[commlist.size()];
        commlist.toArray(commonArry);
        return commonArry;
    }

}
