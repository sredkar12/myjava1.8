package com.learnJava.data.datastructures;

public class SinglyLinkedList {
    EmployeeNode head;

    public void addToFront(Employee employee) {
        EmployeeNode node = new EmployeeNode(employee);
        node.next = head;
        head = node;
    }

    public void printLinkedlist() {
        System.out.print("head ---> ");
        while(head != null ) {
            head.printNode();
            System.out.print(" head --->");
            head = head.getNext();
        }
    }


}
