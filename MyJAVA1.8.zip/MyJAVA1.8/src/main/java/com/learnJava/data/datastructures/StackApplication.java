package com.learnJava.data.datastructures;

public class StackApplication {

    public static void main(String[] args) {
        StackBackedByArray stackArr = new StackBackedByArray(8);
        StackBackedByLinkedList stackBackedByLinkedList = new StackBackedByLinkedList();

        // Creating a stack using the Array backing data structure
        stackArr.push(new Employee("Sameer", "redkar", 21));
        stackArr.push(new Employee("Vidya", "redkar", 22));
        stackArr.push(new Employee("Arjun", "redkar", 23));
        stackArr.push(new Employee("Raju", "redkar", 24));
        stackArr.push(new Employee("Neal", "redkar", 25));
        System.out.println("printing stack");
        stackArr.printStack();
        stackArr.push(new Employee("Bhoj", "redkar", 26));
        System.out.println("printing stack after pusshing bhoj");
        stackArr.printStack();

        stackArr.pop();

        System.out.println("printing stack after popping");
        stackArr.printStack();

        System.out.println("Now will create a stack using linked list \n\n");

        // Now creating a stack using the linked list backing data structure
        stackBackedByLinkedList.push(new Employee("Klan", "redkar", 21));
        stackBackedByLinkedList.push(new Employee("Hira", "redkar", 22));
        stackBackedByLinkedList.push(new Employee("John", "redkar", 23));
        stackBackedByLinkedList.push( new Employee("Kevin", "redkar", 23));
        stackBackedByLinkedList.printStack();

        stackBackedByLinkedList.pop();
        stackBackedByLinkedList.printStack();
        System.out.println("stack after adding 2 to last  \n ");
        stackBackedByLinkedList.addlast(new Employee("Darren", "redkar", 23));
        stackBackedByLinkedList.addlast(new Employee("Larry", "redkar", 23));
        stackBackedByLinkedList.printStack();
        System.out.println("stack after remove first  \n ");
        stackBackedByLinkedList.removeFirst();
        stackBackedByLinkedList.printStack();

        //System.out.println(stackBackedByLinkedList.peek());
//        stack after removing first
//
//        Printing linkedlist stack
//        Employee{firstName='John', lastName='redkar', id=23}
//        Employee{firstName='Hira', lastName='redkar', id=22}
//        Employee{firstName='Klan', lastName='redkar', id=21}
//        Employee{firstName='Darren', lastName='redkar', id=23}


    }

}
