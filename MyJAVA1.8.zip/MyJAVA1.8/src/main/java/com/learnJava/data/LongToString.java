package com.learnJava.data;

public class LongToString {

    public static void main(String[] args) {
        Long l = 12345L;
        String str = Long.toString(l);
        System.out.println(str); //prints '12345'

    }



}
