package com.learnJava.data.datastructures;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MaximumCount {

    public static void main(String[] args) {
        int[] intArray = {9, 7, 8, 1, 6, 9, 17, 9, 18,9, 1, 2, 3};

        int element = maxCountinarry(intArray);
        System.out.println("max is " + element);

    }

    private static int maxCountinarry(int[] intArray) {

        Map<Integer, Integer> countMap = new HashMap<>();

        for (int i = 0; i < intArray.length; ++i) {
            if (countMap.containsKey(intArray[i])){
                int count = countMap.get(intArray[i]);
                countMap.put(intArray[i],++count);
            }
            else {
                countMap.put(intArray[i], 1);
            }
        }
        System.out.println(countMap);
        Set<Integer> kset =  countMap.keySet();
        Iterator<Integer> iterk = kset.iterator();
        while(iterk.hasNext()) {
            System.out.println("iter next key is " + iterk.next());
        }
        Iterator<Map.Entry<Integer, Integer>> iter = countMap.entrySet().iterator();
        int maxcount = 0, eachcount = 0;
        int key = 0;
        while (iter.hasNext()) {
            Map.Entry<Integer, Integer> entry = iter.next();
            eachcount = entry.getValue();
            if (eachcount > maxcount) {
                maxcount = eachcount;
                key = entry.getKey();
            }
        }
        System.out.println("max count is " + maxcount);
        return key;
    }
}
