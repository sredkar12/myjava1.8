package com.learnJava.data.datastructures;

public class Treeexample {
    Treenode root;

    public void addNode(int data){
        if (root == null ) {
            root = new Treenode(data);
        }
        else
            root.insert(data);
    }
    public Treenode get(int value)  {
        if (root != null)
        return root.get(value);
        else
            return null;
    }

    public void  traverseInOrder() {
        if ( root != null ) {
            root.traverseinorder();
        }
    }


}
