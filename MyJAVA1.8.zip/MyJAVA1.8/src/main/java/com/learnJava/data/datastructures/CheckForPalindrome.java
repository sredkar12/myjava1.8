package com.learnJava.data.datastructures;

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Random;

public class CheckForPalindrome {

    public static void main(String[] args) {
        String str1 = "I did , did I ?";
        String str2 = "Dad I am here" ;

        int max = 10;
        int min = 1;
        int randomNum;
        Random rand = new Random();
        randomNum = rand.nextInt((max - min) + 1) + min;
        System.out.println(randomNum);
        randomNum = rand.nextInt((max - min) + 1) + min;
        System.out.println(randomNum);
        randomNum = rand.nextInt((max - min) + 1) + min;
        System.out.println(randomNum);


       // System.out.println("palindrome is " +  checkForPalindrome(str1));
        System.out.println("palindrome is " +  checkForPalindrome(str2));

    }

    private static boolean checkForPalindrome(String string) {
        String lowercase = string.toLowerCase();

        LinkedList<Character> stack = new LinkedList<>();
        LinkedList<Character> queue = new LinkedList<>();

        for(int i = 0; i < lowercase.length(); ++i) {
           char c = lowercase.charAt(i);
           if( c >= 'a' && c <= 'z') {
               stack.push(c);
               queue.addLast(c);
           }
        }
        System.out.println("printing stack ");
        printStack(stack);
        System.out.println("printing queue ");
        printStack(queue);


        while(!stack.isEmpty()) {
            if ( !stack.pop().equals(queue.removeFirst()) ) {
                return false;
            }
        }
         return true;


    }

    public static void printStack(LinkedList<Character> datastruct) {

        ListIterator<Character> iterator = datastruct.listIterator();
        while(iterator.hasNext()) {
            System.out.println(iterator.next());
        }

    }

}
