package com.learnJava.data.datastructures;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class StackBackedByLinkedList {

    LinkedList<Employee> linkedStack  = new LinkedList<>();

    public void push(Employee employee) {
        linkedStack.push(employee);
    }

    Employee pop() {
        return linkedStack.pop();
    }

    public Employee peek() {
        System.out.println("Peeking linkedlist stack");
        return linkedStack.peek();
    }

    public boolean ifEmpty() {
        return linkedStack.isEmpty();
    }

    public void addlast(Employee employee) {
        linkedStack.addLast(employee);
    }
    public Employee removeFirst(){ return linkedStack.removeFirst(); }

    public void addfirst(Employee employee) {
        linkedStack.addFirst(employee);
    }
     public void printStack() {
         System.out.println("Printing linkedlist stack");
         ListIterator<Employee> iterator = linkedStack.listIterator();
         while(iterator.hasNext()) {
             System.out.println(iterator.next());
         }


     }
}
