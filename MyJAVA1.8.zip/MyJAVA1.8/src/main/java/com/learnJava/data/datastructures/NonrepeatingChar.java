package com.learnJava.data.datastructures;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class NonrepeatingChar {

    public static void main(String[] args) {
       String str = "abcabcmmdd";

        Character ch = maxCountinarry(str);
        System.out.println("non repeating is " + ch);

    }

    private static Character maxCountinarry(String str) {

        Map<Character, Integer> countMap = new HashMap<>();

        for (int i= 0; i < str.length(); ++i) {
            if (countMap.containsKey(str.charAt(i))){
                int count = countMap.get(str.charAt(i));
                countMap.put(str.charAt(i),++count);
            }
            else {
                countMap.put(str.charAt(i), 1);
            }
        }
        System.out.println(countMap);

        Iterator<Map.Entry<Character, Integer>> iter = countMap.entrySet().iterator();
        int maxcount = 0, eachcount = 0;
        int key = 0;
        while (iter.hasNext()) {
            Map.Entry<Character, Integer> entry = iter.next();
            eachcount = entry.getValue();
            if (eachcount == 1) {
                return entry.getKey();
            }
        }

        return null;
    }
}
