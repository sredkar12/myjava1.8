package com.learnJava.data.datastructures;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class Linkedlistexmple {

    public static void main(String[] args) {

        String[] listNames = {"sam", "red", "vid", "ajay", "atul"};

        LinkedList<String> listnames = new LinkedList<>();
        listnames.add("sam");
        listnames.add("red");
        listnames.add("vid");
        listnames.add("arun");
        listnames.add("sham");
        listnames.add("jack");

        Iterator<String> iter= listnames.iterator();
        while(iter.hasNext()){
            System.out.println(iter.next());
        }

        listnames.remove();
         iter= listnames.iterator();
        while(iter.hasNext()){
            System.out.println(iter.next());
        }


        System.out.println("Now creating it a stack ");
      listnames.clear();
        listnames = new LinkedList<>();
        listnames.push("sam");
        listnames.push("red");
        listnames.push("vid");
        listnames.push("arun");
        listnames.push("sham");
        listnames.push("jack");

        listnames.forEach( s -> System.out.println(s));
        listnames.pop();
        System.out.println("after popping the stack :");
        listnames.forEach( s-> System.out.println(s));

        listnames.clear();
        System.out.println("now creating a linked list but like a queue :");
        listnames = new LinkedList<>();
        listnames.addLast("sam");
        listnames.addLast("red");
        listnames.addLast("vid");
        listnames.addLast("arun");
        listnames.addLast("sham");
        listnames.addLast("jack");
        listnames.forEach( s-> System.out.println(s));
        listnames.removeFirst();
        System.out.println("after removing first eleement :");
        listnames.forEach( s-> System.out.println(s));


        System.out.println("now creating a queue :");
        Queue<String> queue = new LinkedList<>();

        queue.add("sam");
        queue.add("red");
        queue.add("vid");
        queue.add("arun");
        queue.add("sham");
        queue.add("jack");
        queue.forEach( s-> System.out.println(s));

        System.out.println("now removing  an element from  queue :");
        String element2 = queue.remove();
        queue.forEach( s-> System.out.println(s));


        System.out.println("Now creating a prioritiy queue :");
        Queue<Integer> prqu =new PriorityQueue<>();
        prqu.add(21);
        prqu.add(42);
        prqu.add(12);
        prqu.add(9);
        prqu.add(10);
        prqu.add(5);
        prqu.forEach( s-> System.out.println(s));

        prqu.remove();
        System.out.println("After removing one priotiy queue record:");
        prqu.forEach( s-> System.out.println(s));


    }

}
