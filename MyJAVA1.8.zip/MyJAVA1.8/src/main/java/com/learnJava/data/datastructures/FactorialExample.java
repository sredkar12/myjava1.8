package com.learnJava.data.datastructures;

public class FactorialExample {

    public static void main(String[] args) {
        int num = 5;
//        int factorial = calculateFactorial(num);

       ;
       for ( int i = 0 ; i < 5 ; ++i) {
           System.out.println((int)(Math.random()*100));
       }
//        int factorial = recursiveFactorial(num);
//        System.out.println(factorial);

    }

    private static int recursiveFactorial(int num) {
        if ( num == 0)
            return 1;
        return num * recursiveFactorial(num - 1);
    }

    private static int  calculateFactorial(int num) {
        if ( num == 0)
            return 1;

//        int factorial = num;
//        for(int i = num - 1 ; i > 0 ;  i--) {
//            factorial = factorial *  i;
//        }
        int factorial = 1;
        for(int i = 1 ; i <= num ;  i++) {
            factorial *=  i;
        }

        return factorial;
    }



}
