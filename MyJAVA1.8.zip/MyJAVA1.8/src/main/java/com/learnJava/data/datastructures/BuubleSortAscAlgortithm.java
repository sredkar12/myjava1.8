package com.learnJava.data.datastructures;

public class BuubleSortAscAlgortithm {

    public static void main(String[] args) {
        int[] intArray = { 21, 35, -15 , 5, 55, 1, -22 };

        for ( int unsorted = intArray.length -1; unsorted > 0 ; unsorted--  ) {

            for(int i = 0; i < unsorted; i++ ) {
                if (intArray[i] > intArray[i+1]) {
                    swap(intArray, i , i+1);
                }
            }

        }
        printarray(intArray);

    }

    private static void swap(int[] intArray, int i, int j) {
        int temp = intArray[j];
        intArray[j] = intArray[i];
        intArray[i] = temp;
    }
    private static void printarray(int[] intArray) {
        System.out.println();
        for (int i = 0; i < intArray.length; ++i) {
            System.out.print(intArray[i] + " ");
        }
    }

}
