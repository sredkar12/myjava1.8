package com.learnJava.data.datastructures;

import java.util.Scanner;

public class PalindromeExample {

    public static void main(String[] args) {
      boolean palin = true;
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();

        char[] rev = new char[str.length()];
        System.out.println("str entered is : "  + str);

        int j = 0;
        for(int i = str.length() - 1; i >= 0 ; i--) {
            rev[j++] = str.charAt(i);
        }

        String reversestr = new String(rev);
        System.out.println("str reversed is : "  + reversestr);

//        for(int i = str.length() - 1; i > 0 ; i--) {
//           if(str.charAt(i) != reversestr.charAt(i)) {
//               palin = false;
//               break;
//           }
//
//        }
        for(int i = 0; i < str.length() -1  ; i++) {
            if(str.charAt(i) != reversestr.charAt(i)) {
                palin = false;
                break;
            }

        }
          System.out.println("palindrome is " + palin);
    }

}
