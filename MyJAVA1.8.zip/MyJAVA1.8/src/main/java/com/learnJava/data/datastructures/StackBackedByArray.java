package com.learnJava.data.datastructures;

import java.util.EmptyStackException;

public class StackBackedByArray {

    Employee[] stack ;
    int top;


    public StackBackedByArray(int capacity) {
        stack = new Employee[capacity];
    }

    void push(Employee employee) {
        if (top == stack.length) {
            Employee[] newEmpArray = new Employee[2 * stack.length];
            System.arraycopy(stack,0,newEmpArray,0 , stack.length);
            stack = newEmpArray;
        }
           stack[top++] = employee;
    }
     Employee pop() {
        if (top == 0) {
            throw  new EmptyStackException();
        }
          Employee emp = stack[--top];
          stack[top] = null;
          return emp;

     }

    Employee peek() {
        if (top == 0) {
            throw  new EmptyStackException();
        }
        Employee emp =  stack[top - 1];
        return emp;

    }
      void printStack() {
          System.out.println("Printing Array stack");
          for(int i = top - 1; i >=0 ; --i) {
              System.out.println(stack[i]);
          }
      }

}
