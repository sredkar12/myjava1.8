package com.learnJava.data.datastructures;

import java.util.ArrayList;
import java.util.List;

public class ListExamples {


    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>();

        list.add(new Employee("Sameer", "redkar", 21));
        list.add(new Employee("Vidya", "redkar", 22));
        list.add(new Employee("Arjun", "redkar", 23));

        list.forEach(employee -> System.out.println(employee));

            System.out.println();
        list.set(1,new Employee("Kart", "Redkar", 6));
        list.forEach(employee -> System.out.println(employee));

        System.out.println();
        list.add(2,new Employee("Nor,", "Redkar", 6));
        list.forEach(employee -> System.out.println(employee));

         Employee[] empArr =  list.toArray(new Employee[list.size()]);

        System.out.println("printing emplyee as an array ");
         for(Employee employee: empArr) {
             System.out.println(employee);
         }

        System.out.println(list.contains(new Employee("Nor,", "Redkar", 6)));



    }



}
