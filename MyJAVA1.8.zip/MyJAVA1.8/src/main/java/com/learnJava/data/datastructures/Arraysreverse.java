package com.learnJava.data.datastructures;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Arraysreverse {

    public static void main(String[] args) {
        Integer[] numbers = { 10, 99, 45, 17, 7 , 88, 48, 23 , 10, 101, 32};

        Arrays.sort(numbers);
      System.out.println("sorted array");
        for(Integer i: numbers) {
            System.out.println(i);
        }
        System.out.println("find number 32 using binary search ");
        int index = Arrays.binarySearch(numbers,32);
        System.out.println("32 using binary search  is at index " + index);

        System.out.println("reverse list");
        List<Integer> intlist =  Arrays.asList(numbers);
        Collections.reverse(intlist);
        intlist.forEach(s->  System.out.println(s));

         Integer[] intarr = intlist.toArray(new Integer[intlist.size()]);

         System.out.println("priniting reverse array");
          for(Integer i: intarr)
              System.out.println(i);

    }
}
