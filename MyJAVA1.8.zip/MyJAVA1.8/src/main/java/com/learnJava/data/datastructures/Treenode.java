package com.learnJava.data.datastructures;

public class Treenode {
    private int data ;
    private Treenode leftchild;
    private Treenode rightchild;

    @Override
    public String toString() {
        return "Treenode{" +
            "data=" + data +
            '}';
    }

    void insert(int data) {
        if ( data == this.data)
            return;
        if ( data > this.data ) {
            if ( rightchild == null ) {
                rightchild = new Treenode(data);
            }
            else
                rightchild.insert(data);
        }
        if ( data < this.data ) {
            if ( leftchild == null ) {
                leftchild = new Treenode(data);
            }
            else
                leftchild.insert(data);
        }
    }

    public Treenode get(int value) {
        if ( value == data ) {
            System.out.println("data is " + data);
            return this;
        }
        if ( value < data ) {
            if (leftchild != null ) {
                System.out.println("calling next leftchild");
                    leftchild.get(value);
            }
        }
        if ( value > data) {
            if (rightchild != null) {
                    rightchild.get(value);
            }
        }
        return null;

    }

    public int getData(){
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public Treenode getLeftchild() {
        return leftchild;
    }

    public void setLeftchild(Treenode leftchild) {
        this.leftchild = leftchild;
    }

    public Treenode getRightchild() {
        return rightchild;
    }

    public void setRightchild(Treenode rightchild) {
        this.rightchild = rightchild;
    }

    public Treenode(int data){
        this.data = data;
    }

    public void traverseinorder() {
        if( leftchild != null)
            leftchild.traverseinorder();

        System.out.print(data + " ");
        if (rightchild != null )
            rightchild.traverseinorder();
    }
}
