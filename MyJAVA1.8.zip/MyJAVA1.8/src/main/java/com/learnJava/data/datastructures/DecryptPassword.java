package com.learnJava.data.datastructures;


import java.io.*;
    import java.math.*;
    import java.security.*;
    import java.text.*;
    import java.util.*;
    import java.util.concurrent.*;
    import java.util.regex.*;

class DecryptPassword {

    /*
     * Complete the 'decryptPassword' function below.
     *
     * The function is expected to return a STRING.
     * The function accepts STRING s as parameter.
     */
    public static void main(String[] args) {
        String str = "43Ah*ck0rr0nk";
       String decryopted =  decrypt(str);
       System.out.println("decrypted str is " + decryopted);
    }

    public static String decrypt(String str) {
        // Write your code here
        StringBuilder s = new StringBuilder(str);
        char c ;
        char temp;
        for (int i = 0 ; i < s.length(); ++i) {
            if (s.charAt(i) == '*') {
                temp = s.charAt(i-2);
                s.setCharAt(i-2, s.charAt(i-1));
                s.setCharAt(i-1, temp);
            }
            if ( Character.isDigit(s.charAt(i)) ) {
                if ( Character.getNumericValue(s.charAt(i)) == 0) {
                    int j = 0;
                    int digitindex = 0;
                    while(Character.isDigit(s.charAt(j))) {
                        digitindex = j;
                        ++j;
                    }
                    temp = s.charAt(digitindex);
                    s.setCharAt(digitindex, s.charAt(i));
                    s.setCharAt(i,temp);
                }
            }
        }
        String newstr = new String(s);

            return newstr;
    }

}
