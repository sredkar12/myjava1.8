package com.learnJava.data;

import lombok.Data;

@Data
public class Tokenevent {
    String tracenu;
    String clientname;
    String clientnumber;
}
