public class MappingExample {
}
