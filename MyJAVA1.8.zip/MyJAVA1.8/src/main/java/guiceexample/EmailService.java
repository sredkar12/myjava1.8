package guiceexample;

import com.google.inject.Inject;
import com.google.inject.name.Named;

import javax.inject.Singleton;

//import com.google.inject.Singleton;


public class EmailService implements MessageService {

    @Inject @Named("tokenq")
    private  String tokenQueueName;

    @Inject @Named("txnq")
    private  String transactionQueueName;

    public boolean sendMessage(String msg, String receipient) {
        //some fancy code to send email
        System.out.println("Email Message sent to "+receipient+" with message="+msg);
        return true;
    }

}