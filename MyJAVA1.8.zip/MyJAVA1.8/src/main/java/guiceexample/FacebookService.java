package guiceexample;

public class FacebookService implements  MessageService{

    @Override
    public boolean sendMessage(String msg, String receipient) {
        System.out.println("hi Sameer " + msg + " " + receipient);
        return true;
    }
}
