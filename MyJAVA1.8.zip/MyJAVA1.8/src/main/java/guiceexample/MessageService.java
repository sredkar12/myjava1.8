package guiceexample;

import com.google.inject.ImplementedBy;

@ImplementedBy(EmailService.class)
public interface MessageService {

    boolean sendMessage(String msg, String receipient);
}