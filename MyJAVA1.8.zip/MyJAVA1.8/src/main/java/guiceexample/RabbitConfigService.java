package guiceexample;

public interface RabbitConfigService  {

    public void sendMessage() ;
}
