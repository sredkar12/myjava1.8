package guiceexample;


import com.google.inject.AbstractModule;
import com.google.inject.name.Names;


public class AppInjector extends AbstractModule {

    @Override
    protected void configure() {
        //bind the service to implementation class
        bind(MessageService.class).to(EmailService.class);


        bind(RabbitConfigService.class).to(RabbitMyconfigImpl.class);
        bind(String.class)
                .annotatedWith(Names.named("tokenq"))
                .toInstance("tokenQueueName");
        bind(String.class)
                .annotatedWith(Names.named("txnq"))
                .toInstance("transactionQueueName");

    }
}