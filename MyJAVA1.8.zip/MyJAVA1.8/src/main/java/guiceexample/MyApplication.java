package guiceexample;


import com.google.inject.Inject;

public class MyApplication {

    private MessageService msgService;
    private RabbitConfigService rbService;

	//constructor based injector
	@Inject
	public MyApplication(MessageService svc,RabbitConfigService rsvc ){
		msgService = svc;
		rbService = rsvc;
	}


    public boolean sendMessage(String msg, String rec){
        //some business logic here
        return msgService.sendMessage(msg, rec);
    }

    public void sendRabbit(){
        //some business logic here
        rbService.sendMessage();
    }
}