package guiceexample;


import com.google.inject.Inject;

public class MyApplication {

    private MessageService service;
    private RabbitConfigService rbservice;

	//constructor based injector
	@Inject
	public MyApplication(MessageService svc,RabbitConfigService rsvc ){
		this.service=svc;
		this.rbservice = rsvc;
	}

    //setter method injector
//    @Inject
//    public void setService(MessageService svc){
//        this.service=svc;
//    }

    public boolean sendMessage(String msg, String rec){
        //some business logic here
        return service.sendMessage(msg, rec);
    }

    public void sendRabbit(){
        //some business logic here
        rbservice.sendMessage();
    }
}