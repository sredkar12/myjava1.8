package guiceexample;

public class RabbitMyconfigImpl implements RabbitConfigService{
    @Override
    public void sendMessage() {
        System.out.println("rabbitmyconfig sending message");
    }
}
