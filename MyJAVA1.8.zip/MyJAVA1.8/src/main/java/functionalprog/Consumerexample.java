package functionalprog;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;

import java.util.List;
import java.util.function.Consumer;

public class Consumerexample {

      static Consumer<Student> c1 = (student) -> {
          System.out.println("name of student: " + student.getName());
      };
      static Consumer<String> cstr = (a) -> System.out.println("str is " + a.toUpperCase());

    static Consumer<Student> c2 = (student) -> System.out.println("Activities: " + student.getActivities());
      static  List<Student> studentList = StudentDataBase.getAllStudents();




   public static void printNames(){
       studentList.forEach(c1);
   }

    public static void main(String[] args) {

        cstr.accept("Sameer");
        studentList.forEach(c1.andThen(c2));



    }


}
