package functionalprog.streams;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;
import com.learnJava.data.Tokenevent;
import org.apache.maven.surefire.shade.org.apache.commons.lang3.ArrayUtils;

import java.util.*;
import java.util.stream.Collectors;

public class StreamsExample {

    public static void main(String[] args) {
        List<Integer> integerList = new ArrayList<>();
        integerList.add(1);
        integerList.add(2);
        integerList.add(3);

//         Map[] paramArray =  integerList.stream().map(m ->
//                  new HashMap<String, Object>(){
//                      {
//                          put("A", m);
//                          put("B", m);
//                      }
//                  }
//          ).toArray(Map[]::new);
//
//        System.out.println(paramArray[0]);



        List<Student> studentList = StudentDataBase.getAllStudents();
        List<Tokenevent> tokeneventList = StudentDataBase.getAllTokens();
        List<Tokenevent> tokenlist = new ArrayList<>();
        Map<String, List<String>> mapActivities = StudentDataBase.getAllStudents().stream()
                .filter((student)->student.getGpa()>=3)
                .collect(Collectors.toMap(Student::getName,Student::getActivities));


        Map<String, List<String>> mapActiv = StudentDataBase.getAllStudents().stream()
                .filter((student)->student.getGpa()>=3)
                .collect(Collectors.toMap(Student::getName,Student::getActivities));


        int size = tokeneventList.size();
        Map<String,String>[] mapArray = new Map[size];

        Iterator<Tokenevent> iter = tokeneventList.iterator();
        int i = 0;
         while(iter.hasNext()) {
             Tokenevent event = iter.next();
             Map<String, String> map = new HashMap<>();
             map.put("tracenu" ,"363636");
             map.put("clientname", "sam");
             mapArray[i] = map;
             ++i;
         }
         for(i=0;i<size;++i) {
             //System.out.println(mapArray[i]);
         }

        //System.out.println(mapActivities);
        //System.out.println(mapActivities);

        Map[] paramsArray =  integerList.stream().map(m -> {
            Map<String, String> map = new HashMap<>();
            map.put("tracenu" ,"31111");
            map.put("clientname", "sameeee");
            return map;
        }).toArray(Map[]::new);
        System.out.println(paramsArray[0]);
        System.out.println(paramsArray[1]);
        System.out.println(paramsArray[2]);

    }
}
