package functionalprog;

import java.util.function.BiConsumer;

public class BiConsumerExample {

    public static void main(String[] args) {

        BiConsumer<Integer,Integer> multiple = (a,b)-> System.out.println("Multiply is " + (a*b));
        BiConsumer<Integer,Integer> divide = (a,b)-> System.out.println("divide is " + (a/b));
        multiple.andThen(divide).accept(50,10);
    }
}
