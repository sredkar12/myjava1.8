package functionalprog;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class PredicateandBiConsumer {

    static Predicate<Student> p1 = student -> student.getGradeLevel() > 2;
    static Predicate<Student> p2 = student ->  student.getGpa() > 3.6;

    public static void main(String[] args) {

        BiPredicate<Integer, Double> biPredicate = (grade,gpa)-> grade > 2 && gpa > 3.8;

        BiConsumer<String, List<String>> studact = (s1, s2)-> System.out.println( s1 + " : " + s2 );



        List<Student> stlist = StudentDataBase.getAllStudents();

        //print all students whose gpa is >= 3 and grade > 2 using predicate and biconsumer
        stlist.forEach( s -> {
            if(p1.and(p2).test(s)) {
                studact.accept(s.getName(),s.getActivities());
            }
        });


//print all students whose gpa is >= 3 and grade > 2 using Bipredicate and Biiconsumer
        stlist.forEach( s -> {
            if(biPredicate.test(s.getGradeLevel(),s.getGpa())) {
                studact.accept(s.getName(),s.getActivities());
            }
        });

        List<String> listNames = Arrays.asList("Sameer", "Vidya", "Arjun");
        //listNames.forEach( s -> System.out.println(s));

        String[] names = listNames.toArray(new String[listNames.size()]);


    }
}
