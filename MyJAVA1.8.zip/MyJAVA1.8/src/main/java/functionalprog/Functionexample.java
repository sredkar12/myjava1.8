package functionalprog;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;

public class Functionexample {

    static Function<String, String> upperStr = s -> s.toUpperCase();

    static Function<String, String> concatStr = s -> s.concat("Default");

    static BiFunction<List<Student>, Predicate<Student>, Map<String,Double>> biFunction = (studentlist, studentPredicate) ->
    {
        Map<String, Double> stumap = new HashMap<>();
        studentlist.forEach( student -> {
            if(studentPredicate.test(student))
                stumap.put(student.getName(), student.getGpa());
        } );
       return stumap;
    };



    public static void main(String[] args) {

        System.out.println(upperStr.apply("Sameer"));
        System.out.println(concatStr.apply("Sameer"));
        System.out.println(concatStr.andThen(upperStr).apply("Sameer"));
        System.out.println(concatStr.compose(upperStr).apply("Sameer"));

        Map<String, Double> stmap = biFunction.apply(StudentDataBase.getAllStudents(), PredicateandBiConsumer.p2);

        Iterator<Entry<String, Double>> iter = stmap.entrySet().iterator();
        while( iter.hasNext()) {
            System.out.println(iter.next());
        }

    }





}
