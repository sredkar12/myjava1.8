package functionalprog;

import java.util.Comparator;


public class Lamdacompar {
    public static void main(String[] args) {
        Comparator<Integer> compareLamda = (a, b) -> a.compareTo(b);

        System.out.println("demo comparator by lamda " + compareLamda.compare(5,8) );


    }
}
