import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.UUID;

public class DemoTimeStamp {

   public static void main(String[] args) {
       int n;
       for (int i = 0; i < 10 ; ++i )
      {
          Random rnd = new Random();
           n = 1000000 + rnd.nextInt(9000000);
           Long lng = Long.valueOf(n);
           System.out.println("long is " + lng);
      }
//       Timestamp  tsdate = null;
//     String oldsr = "2020-11-12T17:31:56.000+0000";
//       String newStr = null;
//       int index = oldsr.indexOf('T');
//       System.out.println("index  value is " + index);
//   if ( index != -1) {
//       newStr = oldsr.replace('T', ' ').substring(0, 19);
//   }
//    System.out.println("new string is" + newStr);
//       Timestamp timestamp = Timestamp.valueOf(newStr);
//    String tsStr = timestamp.toString();
//
//    System.out.println("ts value is " + tsStr);
//
//       String pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'";
//       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
//
//       try {
//            tsdate = (Timestamp) simpleDateFormat.parse("2020-11-12T06:00:00.000+0000");
//       } catch (ParseException e) {
//           e.printStackTrace();
//       }
//
//            System.out.printf("date is "  + tsdate.toString());
   }
}
