import model.Foo;
import model.Foonew;
import model.FoonewToken;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;
import java.util.function.Consumer;

import static java.lang.System.exit;

public class Seeallfields {

    public static void main(String[] args) {


        Foonew foo = null;
        FoonewToken foonew = new FoonewToken();


        try {
            foo = new Foonew("dadd", 12,"redkar","363636636","330 grey abber dr","Indian","Engineer",18000.0,true);

            getAllFields( foo,foonew);

        } catch (ClassNotFoundException | IllegalAccessException e) {
            e.printStackTrace();
        }

        exit(0);


    }
     static void getAllFields( Object srcObj, Object targetObj) throws ClassNotFoundException, IllegalAccessException {
         List<Field> srcfieldList = new ArrayList<Field>();
         List<Field> targetfieldList = new ArrayList<Field>();
         Object newObj = null;
         System.out.println("runnih 2..");
        // Class tmpClass = Class.forName(classname);


         targetfieldList.addAll(Arrays.asList(targetObj.getClass().getDeclaredFields()));

             srcfieldList.addAll(Arrays.asList(srcObj.getClass().getDeclaredFields()));
             if (srcObj.getClass().getSuperclass() != null)
                 srcfieldList.addAll(0,Arrays.asList(srcObj.getClass().getSuperclass().getDeclaredFields()));

//         for (Field field : fieldList) {
//             if (!Modifier.isStatic(field.getModifiers())) {
//                 field.setAccessible(true);
//                 System.out.println("Found non-static field: " + field.getName() + " : " + field.get(anyObj));
//
//             }
//         }

        Map<String, Object> srcmap = new HashMap<>();
         srcfieldList.stream().forEach(field -> {
             if (!Modifier.isStatic(field.getModifiers())) {
             field.setAccessible(true);
                 try {
                     System.out.println("printing source fields " + field.getName() +  " : " + field.get(srcObj) );
                     srcmap.put(field.getName(), field.get(srcObj));
                 } catch (IllegalAccessException e) {
                     e.printStackTrace();
                 }
             }});

         targetfieldList.stream().forEach(field -> {
             if (!Modifier.isStatic(field.getModifiers())) {
                 field.setAccessible(true);
                 try {
                     //System.out.println("Found non-static field: " + field.getName() +  " : " + field.get(anyObj) );
                     field.set(targetObj,srcmap.get(field.getName()));
                 } catch (IllegalAccessException e) {
                     e.printStackTrace();
                 }
             }});

         targetfieldList.stream().forEach(field -> {
             if (!Modifier.isStatic(field.getModifiers())) {
                 field.setAccessible(true);
                 try {
                     System.out.println("printing target fields: " + field.getName() +  " : " + field.get(targetObj) );
                 } catch (IllegalAccessException e) {
                     e.printStackTrace();
                 }
             }});

     }
}
