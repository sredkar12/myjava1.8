package mappingex;


public class SourceConvertor{

    public static void main(String[] args) {
        SimpleSource primary = new SimpleSource("mumbai","nirmala","Sameer Sparrow","American",
                "Atlanta", "99999","Orion");
        SimpleDestination business = SimpleSourceDestinationMapper.INSTANCE.sourceToDestination(primary);
        System.out.println(business);

    }

}
