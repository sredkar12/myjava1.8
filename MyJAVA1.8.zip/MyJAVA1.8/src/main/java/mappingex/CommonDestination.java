package mappingex;

import lombok.Data;

@Data
public class CommonDestination {

    private String birthcity;
    private String mothername;
}
