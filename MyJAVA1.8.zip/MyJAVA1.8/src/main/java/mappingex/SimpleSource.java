package mappingex;

import lombok.Data;


@Data
public class SimpleSource {

    private String birthcity;
    private String mothername;
    private String name;
    private String description;
    private String city;
    private String ssn;
    private String employer;
    private String countryoforigin;

    public SimpleSource(String birthcity, String mname,String name, String description, String city, String ssn, String emply) {
        this.birthcity = birthcity;
        this.mothername = mname;
        this.name = name;
        this.description = description;
        this.city = city;
        this.ssn = ssn;
        this.employer = emply;
    }
// getters and setters
}