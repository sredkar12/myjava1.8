package mappingex;

import lombok.Data;


@Data
public class SimpleDestination extends CommonDestination{
    private String name;
    private String description;
    private String city;
    private String ssn;
    private String employer;

    @Override
    public String toString() {
        return "SimpleDestination{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", city='" + city + '\'' +
                ", ssn='" + ssn + '\'' +
                ", employer='" + employer + '\'' +
                '}';
    }
}
