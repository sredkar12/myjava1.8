
import java.io.*;

/**
 * This program demonstrates how to read characters from a text file
 * using a BufferedReader for efficiency.
 * @author www.codejava.net
 *
 */
public class FilereaderExample {

    public static void main(String[] args) {
        String directory = System.getProperty("user.home");
        String fileName = "newtokensvcproviderfdx";
        String absolutePath = directory + File.separator + fileName;
        try {
            System.out.println(absolutePath);
            FileReader reader = new FileReader(absolutePath);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;
            StringBuffer strbuf = new StringBuffer("( ");


            while ((line = bufferedReader.readLine()) != null) {
                line = line.trim();
              if ( line.length() > 0 && isUpperCase2(line) )
                  strbuf.append(line + ", ");
            }
             strbuf.append(")");
            System.out.println(strbuf);
            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static boolean isUpperCase2(String s)
    {
        for (int i=0; i<s.length(); i++)
        {
            if (Character.isLowerCase(s.charAt(i)))
            {
                return false;
            }
        }
        return true;
    }
}