package vavrexamples;

import io.vavr.control.Option;
import io.vavr.control.Try;
import java.util.Optional;
import org.junit.Test;

import static junit.framework.TestCase.*;

public class VavrTryexample {

    @Test(expected = ArithmeticException.class)
    public void givenBadCode_whenThrowsException_thenCorrect() {
        int i = 1 / 0;
    }

    @Test
    public void givenBadCode_whenTryHandles_thenCorrect() {
        Try<Integer> result = Try.of(() -> 1 / 0);

        assertTrue(result.isFailure());
    }

    @Test
    public void givenBadCode_whenTryHandles_thenCorrect2() {
        Try<Integer> computation = Try.of(() -> 10 / 2);
        int errorSentinel = computation.getOrElse(-1);
        System.out.println("errorsentinel is " + errorSentinel);
        if (computation.isSuccess()) {
            assertEquals(5, errorSentinel);
           }
    }


    @Test
    public void givenBadCode_whenTryHandles_thenCorrect3() {
        Try<Integer> computation = Try.of(() -> 1 / 0);
        int errorSentinel = computation.getOrElse(-99);
        System.out.println("errorsentinel is " + errorSentinel);
        if (computation.isFailure()) {
            assertEquals(-99, errorSentinel);
        }
    }

    @Test
    public void givenNonNull_whenCreatesOption_thenCorrect() {
        String name = "baeldung";
        Optional<String> nameOption = Optional.of(name);
        System.out.println("nameoption is " + nameOption.isPresent() );
        assertTrue(nameOption.isPresent());


    }
    @Test
    public void givenNull_whenCreatesOption_thenCorrect() {
        String name = null;
        Optional<String> nameOption = Optional.ofNullable(name);
        System.out.println("nameoption is " + nameOption.isPresent() );
        assertFalse(nameOption.isPresent());


    }



}
